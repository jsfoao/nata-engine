Controls:
WASD - Move car
Space - Shoot
R - Restart level