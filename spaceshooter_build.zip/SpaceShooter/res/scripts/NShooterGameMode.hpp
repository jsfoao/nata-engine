#pragma once
#include "nata.h"

namespace Nata
{
	class EOurObject;

	class NShooterGameMode : public NGameMode
	{
	public:

	public:
		NShooterGameMode(){}

		void Begin() override
		{
		}

		void Tick(float dt) override 
		{
		}
	};
}